phpemail - a simple plugin created specifically for a walkthrough on how to create a Plugin
for WHM. 


INSTALLATION: 

Download the phpemail_install.pl script to /root and run it (as root).  
Once completed, you should have an phpemail plugin under WHM => Plugins.


